#include "MultiplayerObjectPoolingEditorModule.h"


void FMultiplayerObjectPoolingEditorModule::StartupModule()
{
}

void FMultiplayerObjectPoolingEditorModule::ShutdownModule()
{
}


IMPLEMENT_MODULE(FMultiplayerObjectPoolingEditorModule, MultiplayerObjectPoolingEditor)
